/**
 * Created by zhongxiaoming on 2015/10/26.
 * Class Application
 */
Application = {};
Application.url = 'http://192.168.4.130/FosEngineWeb3';

